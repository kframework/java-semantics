// Example 81 from page 65 of Java Precisely edition 1 (The MIT Press 2002)
// Author: Peter Sestoft (sestoft@dina.kvl.dk)


class Example81 {
  public static void main(String[] args) {
    for (int i=0; i<=100; i++) 
      System.out.println(i + "! = " + fact(i));
  }

  static double fact(int n) {
    double res = 0.0;
    for (int i=1; i<=n; i++) 
      res += Math.log(i);
    return Math.exp(res);
  }
}

