// Example 84 from page 67 of Java Precisely edition 1 (The MIT Press 2002)
// Author: Peter Sestoft (sestoft@dina.kvl.dk)


class Example84 {
  public static void main(String[] args) {
    StringBuffer res = new StringBuffer();
    for (int i=0; i<args.length; i++)
      res.append(args[i]);
    System.out.println(res.toString());
  }
}

