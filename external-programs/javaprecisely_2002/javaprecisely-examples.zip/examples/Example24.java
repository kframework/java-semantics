// Example 24 from page 19 of Java Precisely edition 1 (The MIT Press 2002)
// Author: Peter Sestoft (sestoft@dina.kvl.dk)


class Access {
  private static int x; 

  static class SI {
    private static int y = x;       // access private x from enclosing class
  }

  static void m() { 
    int z = SI.y;                   // access private y from nested class
  }
}

