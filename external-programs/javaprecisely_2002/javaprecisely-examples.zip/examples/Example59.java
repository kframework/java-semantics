// Example 59 from page 45 of Java Precisely edition 1 (The MIT Press 2002)
// Author: Peter Sestoft (sestoft@dina.kvl.dk)


class Example59 {
  public static void main(String[] args) {
    System.out.println("Infinite loop!  Stop it by pressing ctrl-C\n\n");
    int i=0;
    while (i<10);
      i++;
  }
}

